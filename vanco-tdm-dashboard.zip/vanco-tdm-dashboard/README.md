# Vancomycin Smart TDM Alert

แดชบอร์ดต้นแบบ (concept demo) สำหรับติดตามระดับยา Vancomycin (TDM) ของโรงพยาบาลสุรินทร์
กลุ่มงานเภสัชกรรม — ข้อมูลในโค้ดเป็นข้อมูลจำลองเพื่อการนำเสนอแนวคิดเท่านั้น

## Tech stack
- React 18
- Vite

## รันบนเครื่องตัวเอง (local dev)

```bash
npm install
npm run dev
```

แล้วเปิด `http://localhost:5173`

## Build สำหรับ production

```bash
npm run build
npm run preview
```

ไฟล์ที่ build แล้วจะอยู่ในโฟลเดอร์ `dist/`

## วิธีอัปโหลดขึ้น GitHub

```bash
git init
git add .
git commit -m "Initial commit: Vancomycin Smart TDM Alert dashboard"
git branch -M main
git remote add origin <URL ของ repo บน GitHub>
git push -u origin main
```

## โครงสร้างโปรเจกต์

```
vanco-tdm-dashboard/
├── index.html
├── package.json
├── vite.config.js
├── src/
│   ├── main.jsx
│   └── App.jsx      # หน้า dashboard หลักทั้ง 3 แท็บ
└── README.md
```

## Deploy ขึ้น GitHub Pages (แก้ปัญหา 404)

หน้า 404 ของ GitHub Pages เกิดเพราะมันต้องการไฟล์ที่ **build แล้ว** (`dist/`) ไม่ใช่ source code
(`src/App.jsx` เป็นต้น) ไฟล์ที่แนบมาแก้ให้แล้วด้วย GitHub Actions ที่ build + deploy ให้อัตโนมัติทุกครั้งที่ push:

1. Push โปรเจกต์นี้ (ทั้งโฟลเดอร์ รวม `.github/workflows/deploy.yml`) ขึ้น repo บน GitHub ตามคำสั่งด้านบน
2. เข้า repo บน GitHub → **Settings → Pages**
3. ที่ **Build and deployment → Source** เลือก **"GitHub Actions"** (ไม่ใช่ "Deploy from a branch")
4. รอ workflow รันเสร็จ (ดูที่แท็บ **Actions**) แล้วเปิดลิงก์ที่ขึ้นใต้ Settings → Pages
   รูปแบบจะเป็น `https://<username>.github.io/<repo-name>/`

ถ้าอยากรันเองแบบไม่ใช้ Actions ก็ยังทำได้: `npm run build` แล้วเอาเนื้อหาในโฟลเดอร์ `dist/`
(ไม่ใช่ทั้งโปรเจกต์) ไป push เข้า branch `gh-pages` หรือใช้ Vercel/Netlify ที่จะ build ให้อัตโนมัติเช่นกัน
