import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // Relative base so JS/CSS assets resolve correctly when hosted at
  // https://<username>.github.io/<repo-name>/ (GitHub Pages project sites)
  base: "./",
});
